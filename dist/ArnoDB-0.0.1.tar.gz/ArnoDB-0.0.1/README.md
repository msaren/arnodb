# ArnoDB

[ArnoDB][arnodb] is scraping, analysing and serving platform for various independent timestamped data sources. ArnoDB consists of following modules:

a. User management
b. Scrapers
c. Database adaptors
d. Sequencer
e. Web Rest API
f. Server synchronizer

## Source

Jadda daa.

    docker build -t arnodb ./buildImage/

Note 

## License

ArnoDB is **licensed** under the [GNU Lesser General Public License][LGPL]. The
terms of the license are as follows:
